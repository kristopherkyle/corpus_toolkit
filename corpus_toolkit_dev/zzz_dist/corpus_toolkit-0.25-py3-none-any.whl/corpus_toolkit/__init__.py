name = "corpus_tools"
from corpus_tools import *